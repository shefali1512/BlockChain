import hashlib
from flask import Flask, render_template, request
app = Flask(__name__)
@app.route('/')
def registerCustomers():
   return render_template("registerCustomers.html")

@app.route('/CustomersInformation',methods = ['POST', 'GET'])
def CustomersInformation():
    if request.method == 'POST':
        result = request.form
        b=CustomersChain()
        b.addNewCustomers(result)
        return render_template("showCustomersInfo.html",showCustomersInfo = result)
if __name__ == '__main__':
   app.run(debug = True)


class Customers:
    def __init__(self, no, nonce, data, hashcode, prev):
        self.no=no
        self.nonce=nonce
        self.data=data
        self.hashcode=hashcode
        self.prev=prev

    def getCustomersInfo(self):
        return self.no, self.nonce, self.data, self.hashcode, self.prev

class CustomersChain:
    def __init__(self):
        self.chain=[]
        self.prefix="0000"

    def addNewCustomers(self,data):
        no = len(self.chain)
        nonce = 0

        if len(self.chain)==0:
            prev = "0"
        else:
            prev = self.chain[-1].hashcode

        myHash = hashlib.sha256(str(data).encode('utf-8')).hexdigest()
        print("Created Hash: ",myHash)
        block = Customers(no, nonce, data, myHash, prev)
        
        self.chain.append(block)

    def displayCustomersInfo(self):
        chainDict={}
        for no in range(len(self.chain)):
            chainDict[no]=self.chain[no].getCustomersInfo(self)
        print (chainDict)

    def mineCustomersInfo(self):
        brokenLink =self.checkIfBroken()

        if (brokenLink==None) :
            pass
        else :
            for block in self.chain[brokenLink.no:]:
                print ("Mining Block:",block.getCustomersInfo(self))
                self.mineBlock(block)

    def mineBlock(self, block):
        nonce = 0
        myHash = hashlib.sha256(str(str(nonce)+str(block.data)).encode('utf-8')).hexdigest()
        while myHash[0:4]!=self.prefix:
                myHash = hashlib.sha256(str(str(nonce)+str(block.data)).encode('utf-8')).hexdigest()
                nonce = nonce + 1
        else:
            self.chain[block.no].hashcode = myHash
            self.chain[block.no].nonce = nonce
            if(block.no < len(self.chain)-1):
                self.chain[block.no+1].prev = myHash

    def checkIfBroken(self):
        for no in range(len(self.chain)):
            if(self.chain[no].hashcode[0:4]==self.prefix):
                pass
            else : 
                return self.chain[no]

    def changeCustomersInfo(self, no, data):
        self.chain[no].data = data
        myNewHash=hashlib.sha256(str(str(self.chain[no].nonce)+str(self.chain[no].data)).encode('utf-8')).hexdigest()
        self.chain[no].hashcode = myNewHash