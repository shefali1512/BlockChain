function jump(){
    
}