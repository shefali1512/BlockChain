const { Blockchain, Block } = require("./block");
function addnew() {
    var name = document.getElementById("userName").value;
    var email = document.getElementById("userEmail").value;
    var phone = document.getElementById("userPhone").value;
    var address = document.getElementById("userAddress").value;
    var account = document.getElementById("userAccNo").value;
    alert(" " + name + " " + email + " " + phone + " " + address + " " + account);
    let newblock = new Blockchain();
    newblock.addBlock(new Block(1, "10/07/2018", { Name: name, Email: email, Phone: phone, Address: address, Account: account }));
}
